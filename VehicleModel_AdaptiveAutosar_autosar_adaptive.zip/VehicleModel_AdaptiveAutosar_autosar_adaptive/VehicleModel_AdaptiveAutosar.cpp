//
//  VehicleModel_AdaptiveAutosar.cpp
//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  Code generation for model "VehicleModel_AdaptiveAutosar".
//
//  Model version              : 1.15
//  Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
//  C++ source code generated on : Sun Jul 16 17:23:13 2023
//
//  Target selection: autosar_adaptive.tlc
//  Embedded hardware selection: Intel->x86-64 (Windows64)
//  Code generation objectives: Unspecified
//  Validation result: Not run


#include "VehicleModel_AdaptiveAutosar.h"
#include "rtwtypes.h"

void VehicleModel_AdaptiveAutosar::FaceCameraSensorFaceCameraSensorReceive(ara::
  com::SamplePtr< proxy::events::FaceCameraSensor::SampleType const > elementPtr)
{
  // Receive: '<Root>/Event Receive'
  rtB.EventReceive = *elementPtr;
}

void VehicleModel_AdaptiveAutosar::
  WarningSignalForPreparednessWarningSignalForPreparednessReceive(ara::com::
  SamplePtr< proxy::events::WarningSignalForPreparedness::SampleType const >
  elementPtr)
{
  // Receive: '<Root>/Event Receive3'
  rtB.EventReceive3 = *elementPtr;
}

void VehicleModel_AdaptiveAutosar::SeatingSensorSeatingSensorReceive(ara::com::
  SamplePtr< proxy::events::SeatingSensor::SampleType const > elementPtr)
{
  // Receive: '<Root>/Event Receive1'
  rtB.EventReceive1 = *elementPtr;
}

void VehicleModel_AdaptiveAutosar::
  EyeMovementDetectionSensorEyeMovementDetectionSensorReceive(ara::com::
  SamplePtr< proxy::events::EyeMovementDetectionSensor::SampleType const >
  elementPtr)
{
  // Receive: '<Root>/Event Receive2'
  rtB.EventReceive2 = *elementPtr;
}

void VehicleModel_AdaptiveAutosar::DrivingModeDrivingModeReceive(ara::com::
  SamplePtr< proxy::events::DrivingMode::SampleType const > elementPtr)
{
  // Receive: '<Root>/Event Receive4'
  rtB.EventReceive4 = *elementPtr;
}

// Model step function
void VehicleModel_AdaptiveAutosar::step()
{
  ara::com::SampleAllocateePtr<skeleton::events::EyeAwareness::SampleType>
    *EyeAwarenessAllocateePtrRawPtr;
  ara::com::SampleAllocateePtr<skeleton::events::SteeringWheelMode::SampleType> *
    SteeringWheelModeAllocateePtrRawPtr;
  ara::com::SampleAllocateePtr<skeleton::events::VehicleMotion::SampleType>
    *VehicleMotionAllocateePtrRawPtr;
  ara::com::SampleAllocateePtr<skeleton::events::WarningToDriver::SampleType>
    *WarningToDriverAllocateePtrRawPtr;
  std::shared_ptr< ara::com::SampleAllocateePtr<skeleton::events::EyeAwareness::
    SampleType> > EyeAwarenessAllocateePtrSharedPtr;
  std::shared_ptr< ara::com::SampleAllocateePtr<skeleton::events::
    SteeringWheelMode::SampleType> > SteeringWheelModeAllocateePtrSharedPtr;
  std::shared_ptr< ara::com::SampleAllocateePtr<skeleton::events::VehicleMotion::
    SampleType> > VehicleMotionAllocateePtrSharedPtr;
  std::shared_ptr< ara::com::SampleAllocateePtr<skeleton::events::
    WarningToDriver::SampleType> > WarningToDriverAllocateePtrSharedPtr;
  real_T rtb_Switch2;
  boolean_T rtb_Compare;
  if (FaceCameraSensor) {
    std::shared_ptr<ara::core::Result<size_t>> resultPtr;
    resultPtr = std::make_shared< ara::core::Result<size_t> >
      (FaceCameraSensor->FaceCameraSensor.GetNewSamples(std::move(std::bind
         (&VehicleModel_AdaptiveAutosar::FaceCameraSensorFaceCameraSensorReceive,
          this, std::placeholders::_1)), 1U));
    resultPtr->ValueOrThrow();
  }

  // RelationalOperator: '<S8>/Compare' incorporates:
  //   Constant: '<S8>/Constant'

  rtb_Compare = (rtB.EventReceive == 3.0);
  if (WarningSignalForPreparedness) {
    std::shared_ptr<ara::core::Result<size_t>> resultPtr_0;
    resultPtr_0 = std::make_shared< ara::core::Result<size_t> >
      (WarningSignalForPreparedness->WarningSignalForPreparedness.GetNewSamples
       (std::move(std::bind(&VehicleModel_AdaptiveAutosar::
          WarningSignalForPreparednessWarningSignalForPreparednessReceive, this,
          std::placeholders::_1)), 1U));
    resultPtr_0->ValueOrThrow();
  }

  // Switch: '<S5>/Switch2' incorporates:
  //   Constant: '<S10>/Constant'
  //   Constant: '<S5>/Constant'
  //   Constant: '<S5>/Constant1'
  //   RelationalOperator: '<S10>/Compare'
  //   Switch: '<S5>/Switch1'

  if (rtb_Compare) {
    rtb_Switch2 = 1.0;
  } else if (rtB.EventReceive == 2.0) {
    // Switch: '<S5>/Switch1'
    rtb_Switch2 = rtB.EventReceive3;
  } else {
    rtb_Switch2 = 0.0;
  }

  // End of Switch: '<S5>/Switch2'
  if (SeatingSensor) {
    std::shared_ptr<ara::core::Result<size_t>> resultPtr_1;
    resultPtr_1 = std::make_shared< ara::core::Result<size_t> >
      (SeatingSensor->SeatingSensor.GetNewSamples(std::move(std::bind
         (&VehicleModel_AdaptiveAutosar::SeatingSensorSeatingSensorReceive, this,
          std::placeholders::_1)), 1U));
    resultPtr_1->ValueOrThrow();
  }

  // Logic: '<S5>/Logical Operator' incorporates:
  //   Constant: '<S11>/Constant'
  //   RelationalOperator: '<S11>/Compare'
  //   RelationalOperator: '<S9>/Compare'

  rtb_Compare = ((rtB.EventReceive1 == 1.0) && (rtb_Switch2 != 0.0));
  VehicleMotionAllocateePtrSharedPtr = std::make_shared< ara::com::
    SampleAllocateePtr<skeleton::events::VehicleMotion::SampleType> >
    (VehicleMotion->VehicleMotion.Allocate());
  VehicleMotionAllocateePtrRawPtr = VehicleMotionAllocateePtrSharedPtr.get();

  // Send: '<Root>/Event Send1'
  *VehicleMotionAllocateePtrRawPtr->get() = rtb_Compare;

  // Send event
  VehicleMotion->VehicleMotion.Send(std::move(*VehicleMotionAllocateePtrRawPtr));
  if (EyeMovementDetectionSensor) {
    std::shared_ptr<ara::core::Result<size_t>> resultPtr_2;
    resultPtr_2 = std::make_shared< ara::core::Result<size_t> >
      (EyeMovementDetectionSensor->EyeMovementDetectionSensor.GetNewSamples(std::
        move(std::bind(&VehicleModel_AdaptiveAutosar::
                       EyeMovementDetectionSensorEyeMovementDetectionSensorReceive,
                       this, std::placeholders::_1)), 1U));
    resultPtr_2->ValueOrThrow();
  }

  // Outputs for Enabled SubSystem: '<S2>/EyeAwarenessDetection' incorporates:
  //   EnablePort: '<S3>/Enable'

  if (rtb_Compare) {
    // RelationalOperator: '<S6>/Compare' incorporates:
    //   Constant: '<S6>/Constant'

    rtB.Compare = (rtB.EventReceive2 == 0.0);

    // RelationalOperator: '<S7>/Compare' incorporates:
    //   Constant: '<S7>/Constant'

    rtB.Compare_p = (rtB.EventReceive2 == 1.0);
  }

  // End of Outputs for SubSystem: '<S2>/EyeAwarenessDetection'
  EyeAwarenessAllocateePtrSharedPtr = std::make_shared< ara::com::
    SampleAllocateePtr<skeleton::events::EyeAwareness::SampleType> >
    (EyeAwareness->EyeAwareness.Allocate());
  EyeAwarenessAllocateePtrRawPtr = EyeAwarenessAllocateePtrSharedPtr.get();

  // Send: '<Root>/Event Send2'
  *EyeAwarenessAllocateePtrRawPtr->get() = rtB.Compare_p;

  // Send event
  EyeAwareness->EyeAwareness.Send(std::move(*EyeAwarenessAllocateePtrRawPtr));
  WarningToDriverAllocateePtrSharedPtr = std::make_shared< ara::com::
    SampleAllocateePtr<skeleton::events::WarningToDriver::SampleType> >
    (WarningToDriver->WarningToDriver.Allocate());
  WarningToDriverAllocateePtrRawPtr = WarningToDriverAllocateePtrSharedPtr.get();

  // Send: '<Root>/Event Send3'
  *WarningToDriverAllocateePtrRawPtr->get() = rtB.Compare;

  // Send event
  WarningToDriver->WarningToDriver.Send(std::move
    (*WarningToDriverAllocateePtrRawPtr));
  if (DrivingMode) {
    std::shared_ptr<ara::core::Result<size_t>> resultPtr_3;
    resultPtr_3 = std::make_shared< ara::core::Result<size_t> >
      (DrivingMode->DrivingMode.GetNewSamples(std::move(std::bind
         (&VehicleModel_AdaptiveAutosar::DrivingModeDrivingModeReceive, this,
          std::placeholders::_1)), 1U));
    resultPtr_3->ValueOrThrow();
  }

  // Outputs for Enabled SubSystem: '<S2>/SteeringWheelModeDetection' incorporates:
  //   EnablePort: '<S4>/Enable'

  if (rtb_Compare) {
    // SignalConversion generated from: '<S4>/DrivingMode'
    rtB.DrivingMode = rtB.EventReceive4;
  }

  // End of Outputs for SubSystem: '<S2>/SteeringWheelModeDetection'
  SteeringWheelModeAllocateePtrSharedPtr = std::make_shared< ara::com::
    SampleAllocateePtr<skeleton::events::SteeringWheelMode::SampleType> >
    (SteeringWheelMode->SteeringWheelMode.Allocate());
  SteeringWheelModeAllocateePtrRawPtr =
    SteeringWheelModeAllocateePtrSharedPtr.get();

  // Send: '<Root>/Event Send'
  *SteeringWheelModeAllocateePtrRawPtr->get() = rtB.DrivingMode;

  // Send event
  SteeringWheelMode->SteeringWheelMode.Send(std::move
    (*SteeringWheelModeAllocateePtrRawPtr));
}

// Model initialize function
void VehicleModel_AdaptiveAutosar::initialize()
{
  {
    ara::com::ServiceHandleContainer< proxy::RequiredInterfaceProxy::HandleType >
      handles;
    ara::com::ServiceHandleContainer< proxy::RequiredInterfaceProxy::HandleType >
      handles_0;
    ara::com::ServiceHandleContainer< proxy::RequiredInterfaceProxy::HandleType >
      handles_1;
    ara::com::ServiceHandleContainer< proxy::RequiredInterfaceProxy::HandleType >
      handles_2;
    ara::com::ServiceHandleContainer< proxy::RequiredInterfaceProxy::HandleType >
      handles_3;

    // Initialize service provider instance - EyeAwareness
    EyeAwareness = std::make_shared< skeleton::ProvidedInterfaceSkeleton >(ara::
      com::InstanceIdentifier("7"), ara::com::MethodCallProcessingMode::
      kEventSingleThread);
    EyeAwareness->OfferService();

    // Initialize service provider instance - SteeringWheelMode
    SteeringWheelMode = std::make_shared< skeleton::ProvidedInterfaceSkeleton >
      (ara::com::InstanceIdentifier("2"), ara::com::MethodCallProcessingMode::
       kEventSingleThread);
    SteeringWheelMode->OfferService();

    // Initialize service provider instance - VehicleMotion
    VehicleMotion = std::make_shared< skeleton::ProvidedInterfaceSkeleton >(ara::
      com::InstanceIdentifier("8"), ara::com::MethodCallProcessingMode::
      kEventSingleThread);
    VehicleMotion->OfferService();

    // Initialize service provider instance - WarningToDriver
    WarningToDriver = std::make_shared< skeleton::ProvidedInterfaceSkeleton >
      (ara::com::InstanceIdentifier("9"), ara::com::MethodCallProcessingMode::
       kEventSingleThread);
    WarningToDriver->OfferService();

    // Initialize service requester instance - DrivingMode
    handles = proxy::RequiredInterfaceProxy::FindService(ara::com::
      InstanceIdentifier("1"));
    if (handles.size() > 0U) {
      DrivingMode = std::make_shared< proxy::RequiredInterfaceProxy >
        (*handles.begin());

      // Subscribe event
      DrivingMode->DrivingMode.Subscribe(1U);
    }

    // Initialize service requester instance - EyeMovementDetectionSensor
    handles_0 = proxy::RequiredInterfaceProxy::FindService(ara::com::
      InstanceIdentifier("3"));
    if (handles_0.size() > 0U) {
      EyeMovementDetectionSensor = std::make_shared< proxy::
        RequiredInterfaceProxy >(*handles_0.begin());

      // Subscribe event
      EyeMovementDetectionSensor->EyeMovementDetectionSensor.Subscribe(1U);
    }

    // Initialize service requester instance - FaceCameraSensor
    handles_1 = proxy::RequiredInterfaceProxy::FindService(ara::com::
      InstanceIdentifier("4"));
    if (handles_1.size() > 0U) {
      FaceCameraSensor = std::make_shared< proxy::RequiredInterfaceProxy >
        (*handles_1.begin());

      // Subscribe event
      FaceCameraSensor->FaceCameraSensor.Subscribe(1U);
    }

    // Initialize service requester instance - SeatingSensor
    handles_2 = proxy::RequiredInterfaceProxy::FindService(ara::com::
      InstanceIdentifier("5"));
    if (handles_2.size() > 0U) {
      SeatingSensor = std::make_shared< proxy::RequiredInterfaceProxy >
        (*handles_2.begin());

      // Subscribe event
      SeatingSensor->SeatingSensor.Subscribe(1U);
    }

    // Initialize service requester instance - WarningSignalForPreparedness
    handles_3 = proxy::RequiredInterfaceProxy::FindService(ara::com::
      InstanceIdentifier("6"));
    if (handles_3.size() > 0U) {
      WarningSignalForPreparedness = std::make_shared< proxy::
        RequiredInterfaceProxy >(*handles_3.begin());

      // Subscribe event
      WarningSignalForPreparedness->WarningSignalForPreparedness.Subscribe(1U);
    }
  }
}

// Model terminate function
void VehicleModel_AdaptiveAutosar::terminate()
{
  EyeAwareness->StopOfferService();
  SteeringWheelMode->StopOfferService();
  VehicleMotion->StopOfferService();
  WarningToDriver->StopOfferService();
}

// Constructor
VehicleModel_AdaptiveAutosar::VehicleModel_AdaptiveAutosar():
  rtB()
{
  // Currently there is no constructor body generated.
}

// Destructor
VehicleModel_AdaptiveAutosar::~VehicleModel_AdaptiveAutosar()
{
  // Currently there is no destructor body generated.
}
