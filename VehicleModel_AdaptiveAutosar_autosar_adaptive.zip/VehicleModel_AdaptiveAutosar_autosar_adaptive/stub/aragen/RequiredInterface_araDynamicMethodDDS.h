#ifndef RequiredInterface_ARA_COM_DDS_DYNAMIC_METHOD_WRAPPER_H
#define RequiredInterface_ARA_COM_DDS_DYNAMIC_METHOD_WRAPPER_H

namespace proxy_io
{
}                                      /* namespace proxy_io */

#endif                                 //RequiredInterface_ARA_COM_DDS_DYNAMIC_METHOD_WRAPPER_H
