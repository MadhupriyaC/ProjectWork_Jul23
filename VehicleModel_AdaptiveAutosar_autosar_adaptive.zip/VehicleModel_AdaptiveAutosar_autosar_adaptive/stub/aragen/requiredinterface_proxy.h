/* This file contains ARA Function Cluster ara::com stub implementation.
   This implementation can be used to compile the generated code
   in Simulink. When deploying the generated code outside of Simulink,
   replace this file with an appropriate ARA file.

   Code generated for Simulink Adaptive model: "Model_PW"
   AUTOSAR AP Release: "19-11"
   On: "16-Jul-2023 00:18:40"  */

#ifndef REQUIREDINTERFACE_PROXY_H_
#define REQUIREDINTERFACE_PROXY_H_
#include <memory>
#include <utility>
#include "ara/core/vector.h"
#include "requiredinterface_common.h"

namespace proxy
{
  namespace events
  {
    using DrivingMode = ara::com::ProxyEvent<Double>;
    using EyeMovementDetectionSensor = ara::com::ProxyEvent<Double>;
    using FaceCameraSensor = ara::com::ProxyEvent<Double>;
    using SeatingSensor = ara::com::ProxyEvent<Double>;
    using WarningSignalForPreparedness = ara::com::ProxyEvent<Double>;
  }                                    /* namespace events */

  namespace methods
  {
  }                                    /* namespace methods */

  class RequiredInterfaceProxy {
   public:
    using HandleType = ara::com::ServiceHandleType;
    explicit RequiredInterfaceProxy(const HandleType& handle): mHandle(handle)
    {
      std::string sTopicName;
      sTopicName = "DrivingMode";
      DrivingMode.Init(ara::com::EventFactory::CreateProxyEvent<Double, proxy_io::
                       RequiredInterface_DrivingMode_t>(handle, sTopicName));
      sTopicName = "EyeMovementDetectionSensor";
      EyeMovementDetectionSensor.Init(ara::com::EventFactory::CreateProxyEvent<
        Double, proxy_io::RequiredInterface_EyeMovementDetectionSensor_t>(handle,
        sTopicName));
      sTopicName = "FaceCameraSensor";
      FaceCameraSensor.Init(ara::com::EventFactory::CreateProxyEvent<Double,
                            proxy_io::RequiredInterface_FaceCameraSensor_t>
                            (handle, sTopicName));
      sTopicName = "SeatingSensor";
      SeatingSensor.Init(ara::com::EventFactory::CreateProxyEvent<Double,
                         proxy_io::RequiredInterface_SeatingSensor_t>(handle,
        sTopicName));
      sTopicName = "WarningSignalForPreparedness";
      WarningSignalForPreparedness.Init(ara::com::EventFactory::CreateProxyEvent<
        Double, proxy_io::RequiredInterface_WarningSignalForPreparedness_t>
        (handle, sTopicName));
    }

    virtual ~RequiredInterfaceProxy()
    {
      DrivingMode.Deinit();
      EyeMovementDetectionSensor.Deinit();
      FaceCameraSensor.Deinit();
      SeatingSensor.Deinit();
      WarningSignalForPreparedness.Deinit();
    }

    RequiredInterfaceProxy(const RequiredInterfaceProxy&) = delete;
    RequiredInterfaceProxy& operator = (const RequiredInterfaceProxy&) = delete;
    RequiredInterfaceProxy(RequiredInterfaceProxy&&) = default;
    RequiredInterfaceProxy& operator = (RequiredInterfaceProxy&&) = default;
    static inline ara::com::ServiceHandleContainer<RequiredInterfaceProxy::
      HandleType> FindService(ara::com::InstanceIdentifier instance = ara::com::
      InstanceIdentifier::Any)
    {
      ara::com::ServiceHandleContainer<RequiredInterfaceProxy::HandleType>
        retResult;
      retResult.push_back(ara::com::ServiceFactory::FindService(instance));
      return retResult;
    }

    static inline ara::com::ServiceHandleContainer<RequiredInterfaceProxy::
      HandleType> FindService(ara::core::InstanceSpecifier instanceSpec)
    {
      ara::com::ServiceHandleContainer<RequiredInterfaceProxy::HandleType>
        retResult;
      ara::com::InstanceIdentifierContainer vecInstance(ara::com::runtime::
        ResolveInstanceIDs(instanceSpec));
      if (!vecInstance.empty()) {
        retResult = FindService(vecInstance.front());
      } else {
        retResult = FindService(ara::com::InstanceIdentifier::Any);
      }                                /* if */

      return retResult;
    }

    static inline ara::com::FindServiceHandle StartFindService(ara::com::
      FindServiceHandler<RequiredInterfaceProxy::HandleType> handler, ara::com::
      InstanceIdentifier instance = ara::com::InstanceIdentifier::Any)
    {
      return ara::com::ServiceFactory::StartFindService(handler, instance);
    }

    static inline ara::com::FindServiceHandle StartFindService(ara::com::
      FindServiceHandler<RequiredInterfaceProxy::HandleType> handler, ara::core::
      InstanceSpecifier instanceSpec)
    {
      ara::com::FindServiceHandle retHandle;
      ara::com::InstanceIdentifierContainer vecInstance(ara::com::runtime::
        ResolveInstanceIDs(instanceSpec));
      if (!vecInstance.empty()) {
        retHandle = StartFindService(handler, vecInstance.front());
      } else {
        retHandle = StartFindService(handler, ara::com::InstanceIdentifier::Any);
      }                                /* if */

      return retHandle;
    }

    static inline void StopFindService(ara::com::FindServiceHandle handle)
    {
      ara::com::ServiceFactory::StopFindService(handle);
    }

    RequiredInterfaceProxy::HandleType GetHandle() const
    {
      return mHandle;
    }

    proxy::events::DrivingMode DrivingMode;
    proxy::events::EyeMovementDetectionSensor EyeMovementDetectionSensor;
    proxy::events::FaceCameraSensor FaceCameraSensor;
    proxy::events::SeatingSensor SeatingSensor;
    proxy::events::WarningSignalForPreparedness WarningSignalForPreparedness;
   private:
    HandleType mHandle;
  };
}                                      /* namespace proxy */

#endif                                 // #ifndef REQUIREDINTERFACE_PROXY_H_
