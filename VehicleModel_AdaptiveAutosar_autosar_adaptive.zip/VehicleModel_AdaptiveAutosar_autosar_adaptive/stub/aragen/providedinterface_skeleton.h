/* This file contains ARA Function Cluster ara::com stub implementation.
   This implementation can be used to compile the generated code
   in Simulink. When deploying the generated code outside of Simulink,
   replace this file with an appropriate ARA file.

   Code generated for Simulink Adaptive model: "Model_PW"
   AUTOSAR AP Release: "19-11"
   On: "16-Jul-2023 00:18:39"  */

#ifndef PROVIDEDINTERFACE_SKELETON_H_
#define PROVIDEDINTERFACE_SKELETON_H_
#include <memory>
#include "providedinterface_common.h"

namespace skeleton
{
  namespace events
  {
    using EyeAwareness = ara::com::SkeletonEvent<Boolean>;
    using SteeringWheelMode = ara::com::SkeletonEvent<Double>;
    using VehicleMotion = ara::com::SkeletonEvent<Boolean>;
    using WarningToDriver = ara::com::SkeletonEvent<Boolean>;
  }                                    /* namespace events */

  class ProvidedInterfaceSkeleton {
   public:
    ProvidedInterfaceSkeleton(ara::com::InstanceIdentifier instance, ara::com::
      MethodCallProcessingMode mode = ara::com::MethodCallProcessingMode::
      kEventSingleThread): mHndl(instance), mMethodProcMode(mode)
    {
    }

    ProvidedInterfaceSkeleton(ara::core::InstanceSpecifier instanceSpec, ara::
      com::MethodCallProcessingMode mode = ara::com::MethodCallProcessingMode::
      kEventSingleThread): mMethodProcMode(mode)
    {
      ara::com::InstanceIdentifierContainer vecInstance(ara::com::runtime::
        ResolveInstanceIDs(instanceSpec));
      if (!vecInstance.empty()) {
        mHndl.mInstanceID = vecInstance.front();
      }                                /* if */
    }

    virtual ~ProvidedInterfaceSkeleton()
    {
      StopOfferService();
    }

    ProvidedInterfaceSkeleton(const ProvidedInterfaceSkeleton&) = delete;
    ProvidedInterfaceSkeleton& operator = (const ProvidedInterfaceSkeleton&) =
      delete;
    ProvidedInterfaceSkeleton(ProvidedInterfaceSkeleton&& sklObj) = default;
    ProvidedInterfaceSkeleton& operator = (ProvidedInterfaceSkeleton&& sklObj) =
      default;
    inline void OfferService()
    {
      ara::com::ServiceFactory::CreateService(mHndl);
      mMethodMiddleware.reset(ara::com::MethodFactory::CreateSkeletonMethod<
        ProvidedInterfaceSkeleton, skeleton_io::
        ProvidedInterfaceSkeleton_mthd_dispatcher_t>(mMethodProcMode, this,
        mHndl));
      std::string sTopicName;
      sTopicName = "EyeAwareness";
      EyeAwareness.Init(ara::com::EventFactory::CreateSkeletonEvent<Boolean,
                        skeleton_io::ProvidedInterface_EyeAwareness_t>(mHndl,
        sTopicName));
      sTopicName = "SteeringWheelMode";
      SteeringWheelMode.Init(ara::com::EventFactory::CreateSkeletonEvent<Double,
        skeleton_io::ProvidedInterface_SteeringWheelMode_t>(mHndl, sTopicName));
      sTopicName = "VehicleMotion";
      VehicleMotion.Init(ara::com::EventFactory::CreateSkeletonEvent<Boolean,
                         skeleton_io::ProvidedInterface_VehicleMotion_t>(mHndl,
        sTopicName));
      sTopicName = "WarningToDriver";
      WarningToDriver.Init(ara::com::EventFactory::CreateSkeletonEvent<Boolean,
                           skeleton_io::ProvidedInterface_WarningToDriver_t>
                           (mHndl, sTopicName));
    }

    inline void StopOfferService()
    {
      EyeAwareness.Deinit();
      SteeringWheelMode.Deinit();
      VehicleMotion.Deinit();
      WarningToDriver.Deinit();
      ara::com::ServiceFactory::DestroyService(mHndl);
    }

    skeleton::events::EyeAwareness EyeAwareness;
    skeleton::events::SteeringWheelMode SteeringWheelMode;
    skeleton::events::VehicleMotion VehicleMotion;
    skeleton::events::WarningToDriver WarningToDriver;
   private:
    ara::com::ServiceHandleType mHndl;
    ara::com::MethodCallProcessingMode mMethodProcMode;
    std::shared_ptr<ara::com::SkeletonMethodMiddlewareBase> mMethodMiddleware;
  };
}                                      /* namespace skeleton */

#endif                                 //#ifndef PROVIDEDINTERFACE_SKELETON_H_
