#ifndef ProvidedInterface_ARA_COM_DDS_DYNAMIC_EVENT_WRAPPER_H
#define ProvidedInterface_ARA_COM_DDS_DYNAMIC_EVENT_WRAPPER_H
#include "AdaptiveAUTOSARDDSIdl.h"
#include "AdaptiveAUTOSARDDSIdlPubSubTypes.h"
namespace skeleton_io {
    class ProvidedInterface_EyeAwareness_t final {
        public:
        eprosima_dds::ProvidedInterface_EyeAwareness mEventData;
        eprosima_dds::ProvidedInterface_EyeAwarenessPubSubType mEventDataType;
        ProvidedInterface_EyeAwareness_t(): mEventData{}, mEventDataType{} {
            mEventDataType.setName("Boolean");
        }
        ~ ProvidedInterface_EyeAwareness_t() = default;
        ProvidedInterface_EyeAwareness_t(const ProvidedInterface_EyeAwareness_t&) = default;
        ProvidedInterface_EyeAwareness_t& operator =(const ProvidedInterface_EyeAwareness_t&) & = default;
        ProvidedInterface_EyeAwareness_t(ProvidedInterface_EyeAwareness_t&&) = default;
        ProvidedInterface_EyeAwareness_t& operator =(ProvidedInterface_EyeAwareness_t&&) & = default;
        void eventData( const bool implValue) {
            mEventData.m_Boolean(implValue);
        }
        bool eventData() {
            return mEventData.m_Boolean();
        }
    }; /* class ProvidedInterface_EyeAwareness_t */
    class ProvidedInterface_SteeringWheelMode_t final {
        public:
        eprosima_dds::ProvidedInterface_SteeringWheelMode mEventData;
        eprosima_dds::ProvidedInterface_SteeringWheelModePubSubType mEventDataType;
        ProvidedInterface_SteeringWheelMode_t(): mEventData{}, mEventDataType{} {
            mEventDataType.setName("Double");
        }
        ~ ProvidedInterface_SteeringWheelMode_t() = default;
        ProvidedInterface_SteeringWheelMode_t(const ProvidedInterface_SteeringWheelMode_t&) = default;
        ProvidedInterface_SteeringWheelMode_t& operator =(const ProvidedInterface_SteeringWheelMode_t&) & = default;
        ProvidedInterface_SteeringWheelMode_t(ProvidedInterface_SteeringWheelMode_t&&) = default;
        ProvidedInterface_SteeringWheelMode_t& operator =(ProvidedInterface_SteeringWheelMode_t&&) & = default;
        void eventData( const double implValue) {
            mEventData.m_Double(implValue);
        }
        double eventData() {
            return mEventData.m_Double();
        }
    }; /* class ProvidedInterface_SteeringWheelMode_t */
    class ProvidedInterface_VehicleMotion_t final {
        public:
        eprosima_dds::ProvidedInterface_VehicleMotion mEventData;
        eprosima_dds::ProvidedInterface_VehicleMotionPubSubType mEventDataType;
        ProvidedInterface_VehicleMotion_t(): mEventData{}, mEventDataType{} {
            mEventDataType.setName("Boolean");
        }
        ~ ProvidedInterface_VehicleMotion_t() = default;
        ProvidedInterface_VehicleMotion_t(const ProvidedInterface_VehicleMotion_t&) = default;
        ProvidedInterface_VehicleMotion_t& operator =(const ProvidedInterface_VehicleMotion_t&) & = default;
        ProvidedInterface_VehicleMotion_t(ProvidedInterface_VehicleMotion_t&&) = default;
        ProvidedInterface_VehicleMotion_t& operator =(ProvidedInterface_VehicleMotion_t&&) & = default;
        void eventData( const bool implValue) {
            mEventData.m_Boolean(implValue);
        }
        bool eventData() {
            return mEventData.m_Boolean();
        }
    }; /* class ProvidedInterface_VehicleMotion_t */
    class ProvidedInterface_WarningToDriver_t final {
        public:
        eprosima_dds::ProvidedInterface_WarningToDriver mEventData;
        eprosima_dds::ProvidedInterface_WarningToDriverPubSubType mEventDataType;
        ProvidedInterface_WarningToDriver_t(): mEventData{}, mEventDataType{} {
            mEventDataType.setName("Boolean");
        }
        ~ ProvidedInterface_WarningToDriver_t() = default;
        ProvidedInterface_WarningToDriver_t(const ProvidedInterface_WarningToDriver_t&) = default;
        ProvidedInterface_WarningToDriver_t& operator =(const ProvidedInterface_WarningToDriver_t&) & = default;
        ProvidedInterface_WarningToDriver_t(ProvidedInterface_WarningToDriver_t&&) = default;
        ProvidedInterface_WarningToDriver_t& operator =(ProvidedInterface_WarningToDriver_t&&) & = default;
        void eventData( const bool implValue) {
            mEventData.m_Boolean(implValue);
        }
        bool eventData() {
            return mEventData.m_Boolean();
        }
    }; /* class ProvidedInterface_WarningToDriver_t */
} /* namespace skeleton_io */
#endif //RequiredInterface_ARA_COM_DDS_DYNAMIC_EVENT_WRAPPER_H
