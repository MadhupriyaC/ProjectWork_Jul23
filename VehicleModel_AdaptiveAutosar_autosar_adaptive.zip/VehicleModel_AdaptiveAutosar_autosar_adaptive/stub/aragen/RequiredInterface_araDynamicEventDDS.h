#ifndef RequiredInterface_ARA_COM_DDS_DYNAMIC_EVENT_WRAPPER_H
#define RequiredInterface_ARA_COM_DDS_DYNAMIC_EVENT_WRAPPER_H
#include "AdaptiveAUTOSARDDSIdl.h"
#include "AdaptiveAUTOSARDDSIdlPubSubTypes.h"
namespace proxy_io {
    class RequiredInterface_DrivingMode_t final {
        public:
        eprosima_dds::RequiredInterface_DrivingMode mEventData;
        eprosima_dds::RequiredInterface_DrivingModePubSubType mEventDataType;
        RequiredInterface_DrivingMode_t(): mEventData{}, mEventDataType{} {
            mEventDataType.setName("Double");
        }
        ~ RequiredInterface_DrivingMode_t() = default;
        RequiredInterface_DrivingMode_t(const RequiredInterface_DrivingMode_t&) = default;
        RequiredInterface_DrivingMode_t& operator =(const RequiredInterface_DrivingMode_t&) & = default;
        RequiredInterface_DrivingMode_t(RequiredInterface_DrivingMode_t&&) = default;
        RequiredInterface_DrivingMode_t& operator =(RequiredInterface_DrivingMode_t&&) & = default;
        void eventData( const double implValue) {
            mEventData.m_Double(implValue);
        }
        double eventData() {
            return mEventData.m_Double();
        }
    }; /* class RequiredInterface_DrivingMode_t */
    class RequiredInterface_EyeMovementDetectionSensor_t final {
        public:
        eprosima_dds::RequiredInterface_EyeMovementDetectionSensor mEventData;
        eprosima_dds::RequiredInterface_EyeMovementDetectionSensorPubSubType mEventDataType;
        RequiredInterface_EyeMovementDetectionSensor_t(): mEventData{}, mEventDataType{} {
            mEventDataType.setName("Double");
        }
        ~ RequiredInterface_EyeMovementDetectionSensor_t() = default;
        RequiredInterface_EyeMovementDetectionSensor_t(const RequiredInterface_EyeMovementDetectionSensor_t&) = default;
        RequiredInterface_EyeMovementDetectionSensor_t& operator =(const RequiredInterface_EyeMovementDetectionSensor_t&) & = default;
        RequiredInterface_EyeMovementDetectionSensor_t(RequiredInterface_EyeMovementDetectionSensor_t&&) = default;
        RequiredInterface_EyeMovementDetectionSensor_t& operator =(RequiredInterface_EyeMovementDetectionSensor_t&&) & = default;
        void eventData( const double implValue) {
            mEventData.m_Double(implValue);
        }
        double eventData() {
            return mEventData.m_Double();
        }
    }; /* class RequiredInterface_EyeMovementDetectionSensor_t */
    class RequiredInterface_FaceCameraSensor_t final {
        public:
        eprosima_dds::RequiredInterface_FaceCameraSensor mEventData;
        eprosima_dds::RequiredInterface_FaceCameraSensorPubSubType mEventDataType;
        RequiredInterface_FaceCameraSensor_t(): mEventData{}, mEventDataType{} {
            mEventDataType.setName("Double");
        }
        ~ RequiredInterface_FaceCameraSensor_t() = default;
        RequiredInterface_FaceCameraSensor_t(const RequiredInterface_FaceCameraSensor_t&) = default;
        RequiredInterface_FaceCameraSensor_t& operator =(const RequiredInterface_FaceCameraSensor_t&) & = default;
        RequiredInterface_FaceCameraSensor_t(RequiredInterface_FaceCameraSensor_t&&) = default;
        RequiredInterface_FaceCameraSensor_t& operator =(RequiredInterface_FaceCameraSensor_t&&) & = default;
        void eventData( const double implValue) {
            mEventData.m_Double(implValue);
        }
        double eventData() {
            return mEventData.m_Double();
        }
    }; /* class RequiredInterface_FaceCameraSensor_t */
    class RequiredInterface_SeatingSensor_t final {
        public:
        eprosima_dds::RequiredInterface_SeatingSensor mEventData;
        eprosima_dds::RequiredInterface_SeatingSensorPubSubType mEventDataType;
        RequiredInterface_SeatingSensor_t(): mEventData{}, mEventDataType{} {
            mEventDataType.setName("Double");
        }
        ~ RequiredInterface_SeatingSensor_t() = default;
        RequiredInterface_SeatingSensor_t(const RequiredInterface_SeatingSensor_t&) = default;
        RequiredInterface_SeatingSensor_t& operator =(const RequiredInterface_SeatingSensor_t&) & = default;
        RequiredInterface_SeatingSensor_t(RequiredInterface_SeatingSensor_t&&) = default;
        RequiredInterface_SeatingSensor_t& operator =(RequiredInterface_SeatingSensor_t&&) & = default;
        void eventData( const double implValue) {
            mEventData.m_Double(implValue);
        }
        double eventData() {
            return mEventData.m_Double();
        }
    }; /* class RequiredInterface_SeatingSensor_t */
    class RequiredInterface_WarningSignalForPreparedness_t final {
        public:
        eprosima_dds::RequiredInterface_WarningSignalForPreparedness mEventData;
        eprosima_dds::RequiredInterface_WarningSignalForPreparednessPubSubType mEventDataType;
        RequiredInterface_WarningSignalForPreparedness_t(): mEventData{}, mEventDataType{} {
            mEventDataType.setName("Double");
        }
        ~ RequiredInterface_WarningSignalForPreparedness_t() = default;
        RequiredInterface_WarningSignalForPreparedness_t(const RequiredInterface_WarningSignalForPreparedness_t&) = default;
        RequiredInterface_WarningSignalForPreparedness_t& operator =(const RequiredInterface_WarningSignalForPreparedness_t&) & = default;
        RequiredInterface_WarningSignalForPreparedness_t(RequiredInterface_WarningSignalForPreparedness_t&&) = default;
        RequiredInterface_WarningSignalForPreparedness_t& operator =(RequiredInterface_WarningSignalForPreparedness_t&&) & = default;
        void eventData( const double implValue) {
            mEventData.m_Double(implValue);
        }
        double eventData() {
            return mEventData.m_Double();
        }
    }; /* class RequiredInterface_WarningSignalForPreparedness_t */
} /* namespace proxy_io */
#endif //RequiredInterface_ARA_COM_DDS_DYNAMIC_EVENT_WRAPPER_H
