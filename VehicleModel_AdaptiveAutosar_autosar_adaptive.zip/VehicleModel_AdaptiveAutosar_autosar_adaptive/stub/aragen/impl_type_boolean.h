/* This file contains ARA Function Cluster ara::com stub implementation.
   This implementation can be used to compile the generated code
   in Simulink. When deploying the generated code outside of Simulink,
   replace this file with an appropriate ARA file.

   Code generated for Simulink Adaptive model: "Model_PW"
   AUTOSAR AP Release: "19-11"
   On: "16-Jul-2023 00:18:42"  */

#ifndef IMPL_TYPE_BOOLEAN_H_
#define IMPL_TYPE_BOOLEAN_H_
#include <cstdint>

using Boolean = bool;

#endif                                 //IMPL_TYPE_BOOLEAN_H_
