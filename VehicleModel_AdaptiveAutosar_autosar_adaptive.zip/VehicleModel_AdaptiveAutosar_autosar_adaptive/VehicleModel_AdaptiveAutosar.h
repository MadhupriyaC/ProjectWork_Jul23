//
//  VehicleModel_AdaptiveAutosar.h
//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  Code generation for model "VehicleModel_AdaptiveAutosar".
//
//  Model version              : 1.11
//  Simulink Coder version : 9.7 (R2022a) 13-Nov-2021
//  C++ source code generated on : Sun Jul 16 00:18:31 2023
//
//  Target selection: autosar_adaptive.tlc
//  Embedded hardware selection: Intel->x86-64 (Windows64)
//  Code generation objectives: Unspecified
//  Validation result: Not run


#ifndef RTW_HEADER_VehicleModel_AdaptiveAutosar_h_
#define RTW_HEADER_VehicleModel_AdaptiveAutosar_h_
#include "rtwtypes.h"
#include "providedinterface_skeleton.h"
#include "requiredinterface_proxy.h"
#include <stddef.h>
#include "VehicleModel_AdaptiveAutosar_types.h"
#include <memory>

// Class declaration for model VehicleModel_AdaptiveAutosar
class VehicleModel_AdaptiveAutosar final
{
  // public data and function members
 public:
  // Block signals (default storage)
  struct B {
    real_T EventReceive;               // '<Root>/Event Receive'
    real_T EventReceive3;              // '<Root>/Event Receive3'
    real_T EventReceive1;              // '<Root>/Event Receive1'
    real_T EventReceive2;              // '<Root>/Event Receive2'
    real_T OutportBufferForSteeringWheelMode;
    boolean_T Compare;                 // '<S6>/Compare'
    boolean_T Compare_p;               // '<S7>/Compare'
  };

  // Copy Constructor
  VehicleModel_AdaptiveAutosar(VehicleModel_AdaptiveAutosar const&) = delete;

  // Assignment Operator
  VehicleModel_AdaptiveAutosar& operator= (VehicleModel_AdaptiveAutosar const&)
    & = delete;

  // Move Constructor
  VehicleModel_AdaptiveAutosar(VehicleModel_AdaptiveAutosar &&) = delete;

  // Move Assignment Operator
  VehicleModel_AdaptiveAutosar& operator= (VehicleModel_AdaptiveAutosar &&) =
    delete;

  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  void terminate();

  // Constructor
  VehicleModel_AdaptiveAutosar();

  // Destructor
  ~VehicleModel_AdaptiveAutosar();

  // private data and function members
 private:
  // Block signals
  B rtB;
  std::shared_ptr<proxy::RequiredInterfaceProxy> DrivingMode;
  std::shared_ptr<proxy::RequiredInterfaceProxy> EyeMovementDetectionSensor;
  std::shared_ptr<proxy::RequiredInterfaceProxy> FaceCameraSensor;
  std::shared_ptr<proxy::RequiredInterfaceProxy> SeatingSensor;
  std::shared_ptr<proxy::RequiredInterfaceProxy> WarningSignalForPreparedness;
  std::shared_ptr<skeleton::ProvidedInterfaceSkeleton> EyeAwareness;
  std::shared_ptr<skeleton::ProvidedInterfaceSkeleton> SteeringWheelMode;
  std::shared_ptr<skeleton::ProvidedInterfaceSkeleton> VehicleMotion;
  std::shared_ptr<skeleton::ProvidedInterfaceSkeleton> WarningToDriver;

  // private member function(s) for subsystem '<Root>'
  void FaceCameraSensorFaceCameraSensorReceive(ara::com::SamplePtr< proxy::
    events::FaceCameraSensor::SampleType const > elementPtr);
  void WarningSignalForPreparednessWarningSignalForPreparednessReceive(ara::com::
    SamplePtr< proxy::events::WarningSignalForPreparedness::SampleType const >
    elementPtr);
  void SeatingSensorSeatingSensorReceive(ara::com::SamplePtr< proxy::events::
    SeatingSensor::SampleType const > elementPtr);
  void EyeMovementDetectionSensorEyeMovementDetectionSensorReceive(ara::com::
    SamplePtr< proxy::events::EyeMovementDetectionSensor::SampleType const >
    elementPtr);
  void DrivingModeDrivingModeReceive(ara::com::SamplePtr< proxy::events::
    DrivingMode::SampleType const > elementPtr);
};

//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'VehicleModel_AdaptiveAutosar'
//  '<S1>'   : 'VehicleModel_AdaptiveAutosar/Initialize Function'
//  '<S2>'   : 'VehicleModel_AdaptiveAutosar/Processing'
//  '<S3>'   : 'VehicleModel_AdaptiveAutosar/Processing/EyeAwarenessDetection'
//  '<S4>'   : 'VehicleModel_AdaptiveAutosar/Processing/SteeringWheelModeDetection'
//  '<S5>'   : 'VehicleModel_AdaptiveAutosar/Processing/VehicleAndDriverReadiness'
//  '<S6>'   : 'VehicleModel_AdaptiveAutosar/Processing/EyeAwarenessDetection/Compare To Constant5'
//  '<S7>'   : 'VehicleModel_AdaptiveAutosar/Processing/EyeAwarenessDetection/Compare To Constant6'
//  '<S8>'   : 'VehicleModel_AdaptiveAutosar/Processing/VehicleAndDriverReadiness/Compare To Constant'
//  '<S9>'   : 'VehicleModel_AdaptiveAutosar/Processing/VehicleAndDriverReadiness/Compare To Constant1'
//  '<S10>'  : 'VehicleModel_AdaptiveAutosar/Processing/VehicleAndDriverReadiness/Compare To Constant2'
//  '<S11>'  : 'VehicleModel_AdaptiveAutosar/Processing/VehicleAndDriverReadiness/Compare To Constant3'


//-
//  Requirements for '<Root>': VehicleModel_AdaptiveAutosar

#endif                            // RTW_HEADER_VehicleModel_AdaptiveAutosar_h_
