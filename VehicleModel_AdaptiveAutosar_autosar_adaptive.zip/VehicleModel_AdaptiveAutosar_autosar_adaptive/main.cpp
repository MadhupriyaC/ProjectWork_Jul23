/* Code generated for Simulink model VehicleModel_AdaptiveAutosar */
/* Generated on 16-Jul-2023 */

#include <thread>
#include <semaphore.h>
#include <exception>
#include <csignal>
#include <ara/core/initialization.h>
#include <ara/exec/execution_client.h>
#include <ara/log/logger.h>
#include <ara/log/logging.h>
#include "MainUtils.hpp"
#include "VehicleModel_AdaptiveAutosar.h"

namespace mwSync
{
  /* To synchronize between the main thread and signal handler,  */
  /* the following semaphore and boolean flag will be used. */
  /* They must both be global so the main thread and signal  */
  /* handler can access them. */
  static sem_t baserate_tick;
  static bool halt_application{ false };

  /* This is the signal handler which is called: */
  /*  - When the base rate timer expires */
  /*  - When we need to terminate */
  /* It posts to a semaphore which tells main to do another  */
  /* step or terminate. */
  static void signal_handler(int32_t signalNum)
  {
    if (signalNum == SIGTERM) {
      halt_application = true;
    }                                  /* if */

    static_cast<void>(sem_post(&baserate_tick));
  }
}

/* main() handles the following: */
/*  - Instantiates the model object and owns its memory. */
/*  - Reports the Execution state to ARA */
/*  - Calls the model's initialize and terminate functions. */
/*  - Sets up AsyncFunctionCall objects for each task */
/*      - Since AsyncFunctionCalls create threads, main also  */
/*        temporarily blocks SIGRTMIN and SIGTERM, so the threads  */
/*        will inherit the block and not respond to those  */
/*        signals. */
/*  - Responds to baserate_tick semaphore posts and runs  */
/*     applicable AsyncFunctionCalls. */
int32_t main()
{
  /* Failure return value for signal/semaphore api's. */
  constexpr int32_t SIG_RET_FAIL{ -1 };

  /* Used to control the flow in case of error in any api's used. */
  bool bProceed{ true };

  /* Used to decide whether ara function clusters has been initialized. */
  bool bAraInitialized{ true };

  /* ara function cluster init. */
  const ara::core::Result<void> initStatus{ ara::core::Initialize() };

  if (!initStatus.HasValue()) {
    bProceed = false;
    bAraInitialized = false;
  }                                    /* if */

  if (bAraInitialized) {
    ara::log::Logger & araLog{ ara::log::CreateLogger(
      "VehicleModel_AdaptiveAutosar",
      "Logger for VehicleModel_AdaptiveAutosar's main function.") };

    if (bProceed) {
      if (sem_init(&mwSync::baserate_tick, 0, 0) == SIG_RET_FAIL) {
        araLog.LogError()<<"Unable to initialize baserate_tick semaphore.\n";
        bProceed = false;
      }                                /* if */
    }                                  /* if */

    if (bProceed) {
      /* Register handler for SIGTERM */
      struct sigaction action;
      static_cast<void>(sigemptyset(&action.sa_mask));
      action.sa_handler = &mwSync::signal_handler;
      action.sa_flags = 0;
      if (sigaction(SIGTERM, &action, nullptr) == SIG_RET_FAIL) {
        araLog.LogError()<<"Unable to register SIGTERM handler.\n";
        bProceed = false;
      }                                /* if */
    }                                  /* if */

    /* Report Execution state */
    ara::exec::ExecutionClient exec_client;
    try {
      if (!exec_client.ReportExecutionState(ara::exec::ExecutionState::kRunning))
      {
        araLog.LogError()<<
          "Unable to report running state: ara::exec::ExecutionReturnType::kGeneralError.\n";
        bProceed = false;
      } else {
        araLog.LogVerbose()<<"Adaptive application entering running state.";
      }                                /* if */
    } catch (std::exception const & e) {
      araLog.LogError()<<"Unable to report running state due to exception: "<<
        e.what()<<".\n";
      bProceed = false;
    }

    VehicleModel_AdaptiveAutosar rtObj;
    if (bProceed) {
      /* Initialize Functions */
      try {
        rtObj.initialize();
      } catch (std::exception const & e) {
        araLog.LogError()<<"Unable to initialize: "<<e.what()<<".\n";
        bProceed = false;
      }
    }                                  /* if */

    if (bProceed) {
      /* Before spawning threads with StepFunction objects,  */
      /* block signals so the threads will not receive them. */
      block_signals(araLog);

      /* Create StepFunctions objects to run step functions concurrently. */
      using StepFun = void (VehicleModel_AdaptiveAutosar::*)();
      StepFunction<VehicleModel_AdaptiveAutosar, StepFun> step_sf{ &rtObj,
        &VehicleModel_AdaptiveAutosar::step, araLog };

      /* These tick variables represent how many base rate  */
      /* periods to wait before running a step function.  For  */
      /* example, step1_ticks=3 indicates every  */
      /* third base rate tick, we should run step1(). */
      constexpr double bRate{ 0.200000 };

      /* Start timer running at base rate. */
      Timer stepTimer{ bRate, mwSync::signal_handler, araLog };

      stepTimer.start();

      /* Once threads for the step functions have been created,  */
      /* unblock signals on the main thread so we can receive  */
      /* SIGRTMIN and SIGTERM */
      unblock_signals(araLog);
      araLog.LogVerbose()<<"Starting Step function.";

      /* Main loop, call step functions */
      constexpr int32_t tick_lcm{ 1 };

      int32_t tick{ 0 };

      while (true) {
        if (mwSync::halt_application) {
          break;
        }                              /* if */

        if (sem_wait(&mwSync::baserate_tick) != SIG_RET_FAIL) {
          tick = (tick+1) % tick_lcm;
          step_sf.step();
        }                              /* if */
      }                                /* while */

      step_sf.stop();
    }                                  /* if */

    if (bProceed) {
      try {
        /* Terminate Functions */
        rtObj.terminate();
      } catch (std::exception const & e) {
        araLog.LogError()<<"Unable to terminate: "<<e.what()<<".\n";
        bProceed = false;
      }
    }                                  /* if */

    try {
      if (!exec_client.ReportExecutionState(ara::exec::ExecutionState::
           kTerminating)) {
        araLog.LogError()<<
          "Unable to report terminating state: ara::exec::ExecutionReturnType::kGeneralError.\n";
        bProceed = false;
      } else {
        araLog.LogVerbose()<<"Exiting adaptive application.\n";
      }                                /* if */
    } catch (std::exception const & e) {
      araLog.LogError()<<"Unable to report terminating state due to exception: "<<
        e.what()<<".\n";
      bProceed = false;
    }

    const ara::core::Result<void> deinitStatus{ ara::core::Deinitialize() };

    if (!deinitStatus.HasValue()) {
      bAraInitialized = false;
    }                                  /* if */
  }                                    /* if */

  constexpr int32_t APP_SUCCESS{ 0 };

  constexpr int32_t APP_FAIL{ 1 };

  return ((bAraInitialized && bProceed) ? APP_SUCCESS : APP_FAIL);
}
