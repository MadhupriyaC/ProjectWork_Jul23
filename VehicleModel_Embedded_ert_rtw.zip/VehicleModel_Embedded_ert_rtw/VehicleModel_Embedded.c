/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: VehicleModel_Embedded.c
 *
 * Code generated for Simulink model 'VehicleModel_Embedded'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Sun Jul 16 17:29:16 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "VehicleModel_Embedded.h"
#include "rtwtypes.h"

/* External inputs (root inport signals with default storage) */
ExtU_VehicleModel_Embedded_T VehicleModel_Embedded_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_VehicleModel_Embedded_T VehicleModel_Embedded_Y;

/* Real-time model */
static RT_MODEL_VehicleModel_Embedde_T VehicleModel_Embedded_M_;
RT_MODEL_VehicleModel_Embedde_T *const VehicleModel_Embedded_M =
  &VehicleModel_Embedded_M_;

/* Model step function */
void VehicleModel_Embedded_step(void)
{
  real_T tmp;

  /* Switch: '<S5>/Switch2' incorporates:
   *  Constant: '<S10>/Constant'
   *  Constant: '<S5>/Constant'
   *  Constant: '<S5>/Constant1'
   *  Constant: '<S8>/Constant'
   *  Inport: '<Root>/FaceCameraSensor'
   *  RelationalOperator: '<S10>/Compare'
   *  RelationalOperator: '<S8>/Compare'
   *  Switch: '<S5>/Switch1'
   */
  if (VehicleModel_Embedded_U.FaceCameraSensor == 3.0) {
    tmp = 1.0;
  } else if (VehicleModel_Embedded_U.FaceCameraSensor == 2.0) {
    /* Switch: '<S5>/Switch1' incorporates:
     *  Inport: '<Root>/WarningSignalForPreparedness'
     */
    tmp = VehicleModel_Embedded_U.WarningSignalForPreparedness;
  } else {
    tmp = 0.0;
  }

  /* End of Switch: '<S5>/Switch2' */

  /* Logic: '<S5>/Logical Operator' incorporates:
   *  Constant: '<S11>/Constant'
   *  Inport: '<Root>/SeatingSensor'
   *  RelationalOperator: '<S11>/Compare'
   *  RelationalOperator: '<S9>/Compare'
   */
  VehicleModel_Embedded_Y.VehicleMotion =
    ((VehicleModel_Embedded_U.SeatingSensor == 1.0) && (tmp != 0.0));

  /* Outputs for Enabled SubSystem: '<S2>/EyeAwarenessDetection' incorporates:
   *  EnablePort: '<S3>/Enable'
   */
  /* Outputs for Enabled SubSystem: '<S2>/SteeringWheelModeDetection' incorporates:
   *  EnablePort: '<S4>/Enable'
   */
  if (VehicleModel_Embedded_Y.VehicleMotion) {
    /* Outport: '<Root>/SteeringWheelMode' incorporates:
     *  Inport: '<Root>/DrivingMode'
     *  SignalConversion generated from: '<S4>/DrivingMode'
     */
    VehicleModel_Embedded_Y.SteeringWheelMode =
      VehicleModel_Embedded_U.DrivingMode;

    /* Outport: '<Root>/WarningToDriver' incorporates:
     *  Constant: '<S6>/Constant'
     *  Inport: '<Root>/EyeMovementDetectionSensor'
     *  RelationalOperator: '<S6>/Compare'
     */
    VehicleModel_Embedded_Y.WarningToDriver =
      (VehicleModel_Embedded_U.EyeMovementDetectionSensor == 0.0);

    /* Outport: '<Root>/EyeAwareness' incorporates:
     *  Constant: '<S7>/Constant'
     *  Inport: '<Root>/EyeMovementDetectionSensor'
     *  RelationalOperator: '<S7>/Compare'
     */
    VehicleModel_Embedded_Y.EyeAwareness =
      (VehicleModel_Embedded_U.EyeMovementDetectionSensor == 1.0);
  }

  /* End of Outputs for SubSystem: '<S2>/SteeringWheelModeDetection' */
  /* End of Outputs for SubSystem: '<S2>/EyeAwarenessDetection' */
}

/* Model initialize function */
void VehicleModel_Embedded_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void VehicleModel_Embedded_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
