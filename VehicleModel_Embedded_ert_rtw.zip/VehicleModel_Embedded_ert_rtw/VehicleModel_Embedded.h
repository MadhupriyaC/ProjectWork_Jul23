/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: VehicleModel_Embedded.h
 *
 * Code generated for Simulink model 'VehicleModel_Embedded'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.7 (R2022a) 13-Nov-2021
 * C/C++ source code generated on : Sun Jul 16 00:48:00 2023
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_VehicleModel_Embedded_h_
#define RTW_HEADER_VehicleModel_Embedded_h_
#ifndef VehicleModel_Embedded_COMMON_INCLUDES_
#define VehicleModel_Embedded_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                              /* VehicleModel_Embedded_COMMON_INCLUDES_ */

#include "VehicleModel_Embedded_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T FaceCameraSensor;             /* '<Root>/FaceCameraSensor' */
  real_T SeatingSensor;                /* '<Root>/SeatingSensor' */
  real_T EyeMovementDetectionSensor;   /* '<Root>/EyeMovementDetectionSensor' */
  real_T WarningSignalForPreparedness;
                                     /* '<Root>/WarningSignalForPreparedness' */
  real_T DrivingMode;                  /* '<Root>/DrivingMode' */
} ExtU_VehicleModel_Embedded_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T SteeringWheelMode;            /* '<Root>/SteeringWheelMode' */
  boolean_T VehicleMotion;             /* '<Root>/VehicleMotion' */
  boolean_T EyeAwareness;              /* '<Root>/EyeAwareness' */
  boolean_T WarningToDriver;           /* '<Root>/WarningToDriver' */
} ExtY_VehicleModel_Embedded_T;

/* Real-time Model Data Structure */
struct tag_RTM_VehicleModel_Embedded_T {
  const char_T * volatile errorStatus;
};

/* External inputs (root inport signals with default storage) */
extern ExtU_VehicleModel_Embedded_T VehicleModel_Embedded_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_VehicleModel_Embedded_T VehicleModel_Embedded_Y;

/* Model entry point functions */
extern void VehicleModel_Embedded_initialize(void);
extern void VehicleModel_Embedded_step(void);
extern void VehicleModel_Embedded_terminate(void);

/* Real-time Model object */
extern RT_MODEL_VehicleModel_Embedde_T *const VehicleModel_Embedded_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'VehicleModel_Embedded'
 * '<S1>'   : 'VehicleModel_Embedded/Initialize Function'
 * '<S2>'   : 'VehicleModel_Embedded/Processing'
 * '<S3>'   : 'VehicleModel_Embedded/Processing/EyeAwarenessDetection'
 * '<S4>'   : 'VehicleModel_Embedded/Processing/SteeringWheelModeDetection'
 * '<S5>'   : 'VehicleModel_Embedded/Processing/VehicleAndDriverReadiness'
 * '<S6>'   : 'VehicleModel_Embedded/Processing/EyeAwarenessDetection/Compare To Constant5'
 * '<S7>'   : 'VehicleModel_Embedded/Processing/EyeAwarenessDetection/Compare To Constant6'
 * '<S8>'   : 'VehicleModel_Embedded/Processing/VehicleAndDriverReadiness/Compare To Constant'
 * '<S9>'   : 'VehicleModel_Embedded/Processing/VehicleAndDriverReadiness/Compare To Constant1'
 * '<S10>'  : 'VehicleModel_Embedded/Processing/VehicleAndDriverReadiness/Compare To Constant2'
 * '<S11>'  : 'VehicleModel_Embedded/Processing/VehicleAndDriverReadiness/Compare To Constant3'
 */
#endif                                 /* RTW_HEADER_VehicleModel_Embedded_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
